import React from 'react'

const ComingSoon = () => {
  return (
    <div className='center justify-center align-middle self-center'>ComingSoon</div>
  )
}

export default ComingSoon