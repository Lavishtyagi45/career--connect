export const languageMap = {
    c: 50,
    cpp: 54,
    java: 62,
    python2: 70,
    python3: 71,
    javascript: 63,
    typescript: 74,
    csharp: 51,
    ruby: 72,
    go: 60,
    rust: 73,
    php: 68,
    swift: 83,
    kotlin: 78,
    sql: 82,
  };
  